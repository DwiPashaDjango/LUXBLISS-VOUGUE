<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
    <title><?php echo $__env->yieldContent('title'); ?> &mdash; LuxBliss Vogue</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <!-- General CSS Files -->
    <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/modules/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/modules/fontawesome/css/all.min.css">

    <!-- CSS Libraries -->
    <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/modules/datatables/datatables.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/modules/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css">

    <?php echo $__env->yieldPushContent('css'); ?>

    <!-- Template CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/css/style.css">
    <link rel="stylesheet" href="<?php echo e(asset('admin')); ?>/css/components.css">
    <!-- Start GA -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-94034622-3"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'UA-94034622-3');
    </script>
    <!-- /END GA -->

</head>

<body class="layout-3">
    <div id="app">
        <div class="main-wrapper container">
            <div class="navbar-bg"></div>
            <?php echo $__env->make('layouts.admin.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php echo $__env->make('layouts.admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- Main Content -->
            <div class="main-content">
                <section class="section">
                    <div class="section-header">
                        <h1><?php echo $__env->yieldContent('title'); ?></h1>
                        <?php
                            $routeCheck = Request::routeIs('admin.product')
                        ?>
                        <div class="section-header-breadcrumb">
                            <?php if($routeCheck): ?>
                                <a href="<?php echo e(route('admin.product.create')); ?>" class="btn btn-primary"><i class="fas fa-plus mr-1"></i> Tambah Produk</a>
                            <?php else: ?>
                                <div class="breadcrumb-item active"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></div>
                                <div class="breadcrumb-item"><a href="#">Pages</a></div>
                                <div class="breadcrumb-item"><?php echo $__env->yieldContent('title'); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="section-body">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </section>
            </div>
            <footer class="main-footer">
                <div class="footer-left">
                    Copyright &copy; <?php echo e(date('Y')); ?> LuxBliss Vogue
                </div>
                <div class="footer-right">

                </div>
            </footer>
        </div>
    </div>

    <?php echo $__env->yieldPushContent('modal'); ?>

    <!-- General JS Scripts -->
    <script src="<?php echo e(asset('admin')); ?>/modules/jquery.min.js"></script>
    <script src="<?php echo e(asset('admin')); ?>/modules/popper.js"></script>
    <script src="<?php echo e(asset('admin')); ?>/modules/tooltip.js"></script>
    <script src="<?php echo e(asset('admin')); ?>/modules/bootstrap/js/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('admin')); ?>/modules/nicescroll/jquery.nicescroll.min.js"></script>
    <script src="<?php echo e(asset('admin')); ?>/modules/moment.min.js"></script>
    <script src="<?php echo e(asset('admin')); ?>/js/stisla.js"></script>

    <!-- JS Libraies -->
    <script src="<?php echo e(asset('admin')); ?>/modules/datatables/datatables.min.js"></script>
    <script src="<?php echo e(asset('admin')); ?>/modules/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js"></script>

    <!-- Template JS File -->
    <script src="<?php echo e(asset('admin')); ?>/js/scripts.js"></script>
    <script src="<?php echo e(asset('admin')); ?>/js/custom.js"></script>
    <script type="text/javascript">
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>
    <?php echo $__env->yieldPushContent('js'); ?>
</body>

</html><?php /**PATH C:\laragon\www\LuxBliss-Vogue\resources\views/layouts/admin.blade.php ENDPATH**/ ?>