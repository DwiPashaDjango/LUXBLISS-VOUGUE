<nav class="navbar navbar-secondary navbar-expand-lg">
    <div class="container">
        <ul class="navbar-nav">
            <li class="nav-item <?php echo e(Request::routeIs('dashboard') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('dashboard')); ?>" class="nav-link"><i class="fas fa-fire"></i><span>Dashboard</span></a>
            </li>
            <li class="nav-item <?php echo e(Request::routeIs('designer') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('designer')); ?>" class="nav-link"><i class="fas fa-users"></i><span>Data Designer</span></a>
            </li>
            <li class="nav-item <?php echo e(Request::routeIs('admin.product*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.product')); ?>" class="nav-link"><i class="fas fa-tshirt"></i><span>Data Produk</span></a>
            </li>
            <li class="nav-item <?php echo e(Request::routeIs('admin.order*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.order')); ?>" class="nav-link"><i class="fas fa-shopping-bag"></i><span>Data Penyewaan</span></a>
            </li>
            <li class="nav-item <?php echo e(Request::routeIs('admin.rented*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.rented')); ?>" class="nav-link"><i class="fas fa-shopping-cart"></i><span>Data Pengembalian</span></a>
            </li>
            <li class="nav-item <?php echo e(Request::routeIs('admin.report*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.report')); ?>" class="nav-link"><i class="fas fa-file"></i><span>Laporan Bulanan</span></a>
            </li>
        </ul>
    </div>
</nav><?php /**PATH C:\laragon\www\LuxBliss-Vogue\resources\views/layouts/admin/navbar.blade.php ENDPATH**/ ?>