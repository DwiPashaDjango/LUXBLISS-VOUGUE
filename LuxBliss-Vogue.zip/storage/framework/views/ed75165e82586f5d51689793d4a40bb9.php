

<?php $__env->startSection('title'); ?>
    Laporan Bulanan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <nav class="nav nav-pills flex-column flex-sm-row">
                <a class="flex-sm-fill text-sm-center nav-link" aria-current="page" href="<?php echo e(route('admin.report')); ?>">Laporan Penyewaan</a>
                <a class="flex-sm-fill text-sm-center nav-link active" aria-current="page" href="<?php echo e(route('admin.report.rented')); ?>">Laporan Pengembalian</a>
            </nav>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <div class="mb-2 mt-2">
                <form action="<?php echo e(route('admin.report.rented')); ?>" method="GET">
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="form-group mb-2">
                                <?php
                                    $months = [
                                        1 => 'Januari',
                                        2 => 'Februari',
                                        3 => 'Maret',
                                        4 => 'April',
                                        5 => 'Mei',
                                        6 => 'Juni',
                                        7 => 'Juli',
                                        8 => 'Agustus',
                                        9 => 'September',
                                        10 => 'Oktober',
                                        11 => 'November',
                                        12 => 'Desember'
                                    ];
                                ?>
                                <select name="month" id="month" class="form-control">
                                    <option value="">- Pilih -</option>
                                    <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $number => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($number); ?>"><?php echo e($name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="form-group mb-2">
                                <?php
                                    $currentYear = date('Y');
                                ?>
                                <select name="year" id="year" class="form-control">
                                    <option value="">- Pilih -</option>
                                    <?php for($year = $currentYear; $year > $currentYear - 5; $year--): ?>
                                        <option value="<?php echo e($year); ?>"><?php echo e($year); ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-2">
                            <button type="submit" class="btn btn-primary w-100 mt-1">Tampilkan</button>
                        </div>
                        <div class="col-lg-2">
                            <?php if(!empty($month) && !empty($years)): ?>
                                <a target="_blank" href="<?php echo e(route('admin.report.printReportRented', ['month' => $month, 'years' => $years])); ?>" class="btn btn-danger w-100 mt-1">Cetak</a>
                            <?php else: ?>
                                <a target="_blank" href="<?php echo e(route('admin.report.printReportRented', ['month' => \Carbon\Carbon::now()->month, 'years' => \Carbon\Carbon::now()->year])); ?>" class="btn btn-danger w-100 mt-1">Cetak</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </form>
            </div>
            <div class="alert alert-primary">
                <?php if(!empty($month) && !empty($years)): ?>
                    Laporan Pengembalian Bulan <?php echo e($month); ?> Tahun <?php echo e($years); ?>

                <?php else: ?>
                    Laporan Pengembalian Bulan <?php echo e(\Carbon\Carbon::now()->month); ?> Tahun <?php echo e(\Carbon\Carbon::now()->year); ?>

                <?php endif; ?>
            </div>
            <div class="table-responsive">
                <table class="table table-bordered table-striped text-center">
                    <thead class="bg-primary">
                        <tr>
                            <th class="text-white">No</th>
                            <th class="text-white">Nama Penyewa</th>
                            <th class="text-white">Tanggal Penyewaan</th>
                            <th class="text-white">Tanggal Pengembalian</th>
                            <th class="text-white">Selisih Hari</th>
                            <th class="text-white">Denda</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $renteds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($item->user->name); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($item->rent->start_date)->translatedFormat('d F Y')); ?> - <?php echo e(\Carbon\Carbon::parse($item->rent->end_date)->translatedFormat('d F Y')); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($item->created_at)->translatedFormat('d F Y')); ?></td>
                                <td>
                                    <?php
                                        $endDate = \Carbon\Carbon::parse($item->rent->end_date);
                                        $rentedDate = \Carbon\Carbon::parse($item->created_at);

                                        $selisih = $endDate->diffInDays($rentedDate);
                                    ?>
                                    <?php echo e($selisih); ?>

                                </td>
                                <td>
                                    <?php echo e(number_format($item->denda->total_denda)); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <?php if(!empty($month) && !empty($year)): ?>
                                    <td colspan="6">Tidak Ada Data Pengembalian Di Bulan <?php echo e($month); ?> Tahun <?php echo e($years); ?> </td>
                                <?php else: ?>
                                    <td colspan="6">Tidak Ada Data Pengembalian Di Bulan Tahun </td>
                                <?php endif; ?>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\LuxBliss-Vogue\resources\views/admin/report/rented.blade.php ENDPATH**/ ?>