    <nav class="container navbar navbar-expand-lg main-navbar">
        <a href="<?php echo e(route('dashboard')); ?>" class="navbar-brand sidebar-gone-hide">
            <img src="<?php echo e(asset('logo.png')); ?>" width="50" alt="">
        </a>
        <a href="#" class="nav-link sidebar-gone-show" style="margin-top: 35px;" data-toggle="sidebar"><i class="fas fa-bars"></i></a>
        <div class="form-inline ml-auto">
        </div>
        <ul class="navbar-nav navbar-right">
            <li class="dropdown">
                <a href="#" data-toggle="dropdown" class="nav-link dropdown-toggle nav-link-lg nav-link-user">
                    <img alt="image" src="<?php echo e(asset('admin')); ?>/img/avatar-2.png" class="rounded-circle mr-1">
                    <div class="d-sm-none d-lg-inline-block">Hi, <?php echo e(Auth::user()->name); ?></div>
                </a>
                <div class="dropdown-menu dropdown-menu-right">
                    <div class="dropdown-title"><?php echo e(Auth::user()->email); ?></div>
                    <a href="features-profile.html" class="dropdown-item has-icon">
                        <i class="far fa-user"></i> Profile
                    </a>
                    <div class="dropdown-divider"></div>
                    <a href="<?php echo e(route('logout')); ?>" class="dropdown-item has-icon text-danger">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </li>
        </ul>
    </nav><?php /**PATH C:\laragon\www\LuxBliss-Vogue\resources\views/layouts/admin/topbar.blade.php ENDPATH**/ ?>