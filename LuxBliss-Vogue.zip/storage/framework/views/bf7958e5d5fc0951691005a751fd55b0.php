<div>
    <div class="modal fade" tabindex="-1" role="dialog" id="<?php echo e($id); ?>">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <?php echo e($slot); ?>

            </div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\LuxBliss-Vogue\resources\views/components/modal.blade.php ENDPATH**/ ?>