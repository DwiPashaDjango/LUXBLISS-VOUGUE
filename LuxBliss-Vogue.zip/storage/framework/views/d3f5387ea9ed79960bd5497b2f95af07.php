<nav class="custom-navbar navbar navbar navbar-expand-md navbar-dark bg-dark" arial-label="Furni navigation bar">

    <div class="container">
        <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
            <img src="<?php echo e(asset('logo.png')); ?>" width="50" alt="">
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsFurni" aria-controls="navbarsFurni" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarsFurni">
            <ul class="custom-navbar-nav navbar-nav ms-auto mb-2 mb-md-0">
                <li class="nav-item <?php echo e(request()->is('/') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('home')); ?>">Beranda</a>
                </li>
                <li class="nav-item <?php echo e(request()->is('products*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('product')); ?>">Koleksi</a>
                </li>
                <?php if(auth()->guard()->check()): ?>
                    <li class="nav-item <?php echo e(request()->is('renteds') ? 'active' : ''); ?>">
                        <a class="nav-link" href="<?php echo e(route('rented')); ?>">PenyewaanKu</a>
                    </li>
                <?php endif; ?>
                <li class="nav-item <?php echo e(request()->is('abouts') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('about')); ?>">Tentang Kami</a>
                </li>
                <li class="nav-item <?php echo e(request()->is('contacts') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('contact')); ?>">Hubungi Kami</a>
                </li>
            </ul>

            <ul class="custom-navbar-cta navbar-nav mb-2 mb-md-0 ms-5">
                <?php if(auth()->guard()->check()): ?>
                    <li><a class="nav-link" href="<?php echo e(route('whislist')); ?>"><img width="20" src="<?php echo e(asset('asset/heart.png')); ?>"></a></li>
                    <li><a class="nav-link" href="<?php echo e(route('account')); ?>"><img width="20" src="<?php echo e(asset('asset/user.png')); ?>"></a></li>
                    <li><a class="nav-link" href="<?php echo e(route('logout')); ?>"><img width="20" src="<?php echo e(asset('asset/logout.png')); ?>"></a></li>
                <?php endif; ?>
                <?php if(auth()->guard()->guest()): ?>
                    <li>
                        <a class="btn btn-secondary btn-sm w-100" href="<?php echo e(route('login')); ?>">Login</a>
                    </li>
                    <li>
                        <a class="btn btn-secondary btn-sm w-100" href="<?php echo e(route('register')); ?>">Daftar</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
        
</nav><?php /**PATH C:\laragon\www\LuxBliss-Vogue\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>