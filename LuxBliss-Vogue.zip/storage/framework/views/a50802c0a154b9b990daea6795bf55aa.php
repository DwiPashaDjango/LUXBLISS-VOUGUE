<!doctype html>
<html lang="en">

<head>
    <title><?php echo $__env->yieldContent('title'); ?> &mdash; LuxBliss Vogue</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="<?php echo e(asset('auth')); ?>/css/style.css">
    <link rel="icon" href="<?php echo e(asset('logo.png')); ?>">
    <?php echo $__env->yieldPushContent('css'); ?>
</head>

<body>
    <section class="ftco-section">
        <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </section>

    <script src="<?php echo e(asset('auth')); ?>/js/jquery.min.js"></script>
    <script src="<?php echo e(asset('auth')); ?>/js/popper.js"></script>
    <script src="<?php echo e(asset('auth')); ?>/js/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('auth')); ?>/js/main.js"></script>

</body>

</html><?php /**PATH C:\laragon\www\LuxBliss-Vogue\resources\views/layouts/auth.blade.php ENDPATH**/ ?>