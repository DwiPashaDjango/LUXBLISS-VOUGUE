

<?php $__env->startSection('title'); ?>
    Profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('account.profile', ['id' => Auth::user()->id])); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field("PUT"); ?>
    <div class="container">
        <div class="row py-3">
            <div class="col-lg-8">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-primary">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                <?php endif; ?>
                <div class="card shadow my-3">
                    <div class="card-body m-2">
                        <h4 style="color:black;">
                            Profile Saya
                        </h4>
                        <p style="color:black;">Kelola informasi profil Anda untuk mengontrol, melindungi dan mengamankan akun</p>
                        <hr class="divide">
                        <table style="width:100%; color:black;">
                            <tr style="">
                                <td style="padding-bottom:15px; width:25%;">Nama Lengkap</td>
                                <td style="padding-bottom:15px; width:10%;"></td>
                                <td style="padding-bottom:15px; width:65%;">
                                    <input name="name" id="name" class="form-control" style="border:2px solid #198754; width:100%; height:40px;" value="<?php echo e(Auth::user()->name); ?>" type="text" placeholder="Masukkan Nama Lengkap">
                                </td>                                
                            </tr>
                            <tr>
                                <td style="padding-bottom:15px; width:25%;">Email</td>
                                <td style="padding-bottom:15px; width:10%;"></td>
                                <td style="padding-bottom:15px; width:65%;">
                                    <input name="email" id="email" class="form-control" style="border:2px solid #198754; width:100%; height:40px;" value="<?php echo e(Auth::user()->email); ?>" type="text" placeholder="Masukkan Email">
                                </td>                               
                            </tr>
                            <tr>
                                <td style="padding-bottom:15px; width:25%;">Nomor Telepon</td>
                                <td style="padding-bottom:15px; width:10%;"></td>
                                <td style="padding-bottom:15px; width:65%;">
                                    <input name="telp" id="telp" class="form-control" style="border:2px solid #198754; width:100%; height:40px;" value="084512356889" type="text" placeholder="Masukkan No Telepon     ">
                                </td>                               
                            </tr>
                        </table>
                    </div>
                </div>

                <div class="card shadow my-3">
                    <div class="card-body">
                        <h4 style="color:black;">
                            Alamat Saya
                        </h4>
                        <hr class="divide">
                        <textarea name="alamat" id="alamat" style="border: 2px dashed #198754; padding: 10px; border-radius: 2px" rows="5" cols="5" class="form-control">
                            <?php echo e(Auth::user()->alamat); ?>

                        </textarea>

                        <button type="submit" class="btn btn-primary w-100 mt-3">Simpan</button>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 text-center">
                <?php
                    if (Auth::user()->image === 'default.png') {
                        $image = 'foto/rama.jpg';
                    } else {
                        $image = Auth::user()->image;
                    }
                ?>
                <img id="profilePicture" src="<?php echo e(asset($image)); ?>" alt="Profile Picture" class="rounded-circle my-3" style="width: 200px; height: 200px;">
                <br>
                <input type="file" id="imageInput" name="image" style="display: none;" accept="image/*" onchange="previewImage(event)">
                <button type="button" class="btn" style="background-color: transparent; color: #198754; border: 2px solid #198754;" onclick="document.getElementById('imageInput').click();">Pilih Gambar</button>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        function previewImage(event) {
            const input = event.target;
            const file = input.files[0];
            const img = document.getElementById('profilePicture');

            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    img.src = e.target.result;
                }
                reader.readAsDataURL(file);
            } else {
                img.src = "<?php echo e(asset($image)); ?>";
            }
        }
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\LuxBliss-Vogue\resources\views/pages/account.blade.php ENDPATH**/ ?>